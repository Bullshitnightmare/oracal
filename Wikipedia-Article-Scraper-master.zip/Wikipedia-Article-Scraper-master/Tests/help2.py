from test import testclass

if __name__ == "__main__":
    help(testclass)

def help2test():
    return help(testclass)