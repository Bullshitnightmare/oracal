from test import testclass

if __name__ == "__main__":
    testclass.plotyear('yearcount', 30)