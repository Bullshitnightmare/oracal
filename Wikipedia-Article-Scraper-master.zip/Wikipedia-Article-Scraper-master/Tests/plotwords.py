from test import testclass

if __name__ == "__main__":
    testclass.plotwords('wordcount', 30, 1, 20)