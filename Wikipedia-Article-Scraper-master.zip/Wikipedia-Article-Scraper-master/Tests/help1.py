from test import testclass

if __name__ == "__main__":
    testclass.HELP()

def help1test():
    testclass.HELP()
    return True