from test import testclass

if __name__ == "__main__":
    print(testclass.commonwords(50))

def commonwordstest(num):
    return testclass.commonwords(num)