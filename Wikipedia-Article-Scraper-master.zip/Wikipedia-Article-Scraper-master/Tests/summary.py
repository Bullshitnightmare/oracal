from test import testclass

if __name__ == "__main__":
    testclass.summary(4)

def summarytest(num):
    return testclass.summary(num, True)